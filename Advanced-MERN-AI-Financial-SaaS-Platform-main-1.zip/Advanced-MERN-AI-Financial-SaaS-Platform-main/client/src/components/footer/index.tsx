
const Footer = () => {
  return (
    <footer className="h-16">
        <div className="container"></div>
    </footer>
  )
}

export default Footer